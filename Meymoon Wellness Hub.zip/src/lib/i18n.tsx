import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "ro" | "en";

type Dict = Record<string, { ro: string; en: string }>;

const DICT: Dict = {
  // Nav
  "nav.home": { ro: "Acasă", en: "Home" },
  "nav.classes": { ro: "Clase", en: "Classes" },
  "nav.schedule": { ro: "Program", en: "Schedule" },
  "nav.memberships": { ro: "Abonamente", en: "Memberships" },
  "nav.contact": { ro: "Contact", en: "Contact" },
  "nav.account": { ro: "Cont Client", en: "Client Account" },
  "nav.openMenu": { ro: "Deschide meniul", en: "Open menu" },
  "nav.closeMenu": { ro: "Închide meniul", en: "Close menu" },

  // Footer
  "footer.tagline": {
    ro: "Un studio boutique senin, dedicat Pilates-ului, Yoga-ei și mișcării conștiente.",
    en: "A serene boutique studio dedicated to Pilates, Yoga and mindful movement.",
  },
  "footer.contact": { ro: "Contact", en: "Contact" },
  "footer.explore": { ro: "Explorează", en: "Explore" },
  "footer.newsletter": { ro: "Newsletter", en: "Newsletter" },
  "footer.newsletterText": {
    ro: "Ritualuri, clase noi și momente de liniște — o dată pe lună.",
    en: "Rituals, new classes and quiet moments — once a month.",
  },
  "footer.emailPlaceholder": { ro: "Adresa ta de email", en: "Your email" },
  "footer.join": { ro: "Abonează-te", en: "Join" },
  "footer.hours": { ro: "Luni–Duminică · 07:00 – 22:00", en: "Mon–Sun · 07:00 – 22:00" },
  "footer.rights": { ro: "Toate drepturile rezervate.", en: "All rights reserved." },
  "footer.gdpr": { ro: "Politica GDPR", en: "GDPR Policy" },
  "footer.terms": { ro: "Termeni", en: "Terms" },
  "footer.cookies": { ro: "Cookies", en: "Cookies" },

  // Cookies
  "cookie.text": {
    ro: "Folosim cookie-uri pentru a-ți oferi o experiență rafinată. Continuând, ești de acord cu utilizarea lor.",
    en: "We use cookies to offer you a refined browsing experience. By continuing, you agree to our use of cookies.",
  },
  "cookie.accept": { ro: "Accept", en: "Accept" },
  "cookie.decline": { ro: "Refuz", en: "Decline" },

  // Home
  "home.subtitle": { ro: "Minte · Corp · Spirit", en: "Mind · Body · Spirit" },
  "home.heroLead": {
    ro: "Un refugiu pentru mișcare, respirație și liniște — gândit pentru cele care caută rafinamentul în fiecare gest.",
    en: "A sanctuary for movement, breath and stillness — designed for those who seek refinement in every gesture.",
  },
  "home.bookFirst": { ro: "Rezervă prima experiență", en: "Book Your First Experience" },
  "home.exploreClasses": { ro: "Descoperă clasele", en: "Explore Classes" },
  "home.studio": { ro: "Studioul", en: "The Studio" },
  "home.craftedForStillness": { ro: "Creat pentru liniște.", en: "Crafted for stillness." },
  "home.instructors": { ro: "Instructori", en: "Instructors" },
  "home.guided": { ro: "Ghidate de intenție.", en: "Guided by intention." },
  "home.reviews": { ro: "Recenzii", en: "Reviews" },
  "home.reviewsTitle": { ro: "Ce spun clientele noastre", en: "What our clients say" },
  "home.leaveReview": { ro: "Lasă o recenzie", en: "Leave a review" },
  "home.yourName": { ro: "Numele tău", en: "Your name" },
  "home.yourReview": { ro: "Câteva cuvinte despre experiența ta…", en: "A few words about your experience…" },
  "home.publish": { ro: "Publică", en: "Publish" },
  "home.visitUs": { ro: "Vino în vizită", en: "Visit us" },
  "home.mapTitle": { ro: "Ne găsești în inima Bucureștiului", en: "Find us in the heart of Bucharest" },
  "home.newsletterEyebrow": { ro: "Newsletter Meymoon", en: "Meymoon Newsletter" },
  "home.newsletterTitle": { ro: "Ritualuri lunare, în inbox-ul tău.", en: "Monthly rituals, in your inbox." },
  "home.newsletterText": {
    ro: "Clase noi, ateliere, invitații private și momente de liniște — o scrisoare gândită cu grijă, o dată pe lună.",
    en: "New classes, workshops, private invitations and quiet moments — a carefully considered letter, once a month.",
  },
  "home.newsletterNote": { ro: "Fără spam. Te poți dezabona oricând.", en: "No spam. Unsubscribe anytime." },



  // Benefits
  "ben.light.t": { ro: "Lumină Naturală", en: "Natural Light" },
  "ben.light.x": { ro: "Ferestre înalte și un spațiu calm, scăldat în soare, gândit să restaureze.", en: "Floor-to-ceiling windows and a calm, sunlit space designed to restore." },
  "ben.org.t": { ro: "Materiale Organice", en: "Organic Materials" },
  "ben.org.x": { ro: "Lemn cald, in și piatră — o atmosferă senzorială din primul moment.", en: "Warm woods, linen and stone — a sensory atmosphere from the moment you enter." },
  "ben.mind.t": { ro: "Atmosferă Conștientă", en: "Mindful Atmosphere" },
  "ben.mind.x": { ro: "Clase mici, parfum atent ales, acustică blândă. Fiecare detaliu este intenționat.", en: "Small classes, considered scent, soft acoustics. Every detail is intentional." },
  "ben.amen.t": { ro: "Facilități Premium", en: "Premium Amenities" },
  "ben.amen.x": { ro: "Reformere, spinefitter-uri, lounge, ceainărie și vestiare rafinate.", en: "Reformers, spinefitters, lounge, tea bar and refined changing rooms." },

  // Contact
  "contact.eyebrow": { ro: "Vino în vizită", en: "Visit Us" },
  "contact.title": { ro: "Contact", en: "Contact" },
  "contact.lead": {
    ro: "Te așteptăm în studio. Pentru rezervări și întrebări, scrie-ne sau sună-ne — răspundem cu drag.",
    en: "We look forward to welcoming you. Reach out anytime — we reply with care.",
  },
  "contact.address": { ro: "Adresă", en: "Address" },
  "contact.phone": { ro: "Telefon", en: "Phone" },
  "contact.hours": { ro: "Program", en: "Opening Hours" },
  "contact.whatsapp": { ro: "Scrie-ne pe WhatsApp", en: "Message on WhatsApp" },
  "contact.directions": { ro: "Deschide în Google Maps", en: "Open in Google Maps" },
  "contact.findUs": { ro: "Ne găsești aici", en: "Find us here" },
};

const LanguageContext = createContext<{ lang: Lang; setLang: (l: Lang) => void; t: (k: keyof typeof DICT) => string }>({
  lang: "ro",
  setLang: () => {},
  t: (k) => k as string,
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ro");

  useEffect(() => {
    if (typeof window === "undefined") return;
    const saved = localStorage.getItem("meymoon-lang") as Lang | null;
    if (saved === "ro" || saved === "en") setLangState(saved);
  }, []);

  const setLang = (l: Lang) => {
    setLangState(l);
    if (typeof window !== "undefined") localStorage.setItem("meymoon-lang", l);
  };

  const t = (k: keyof typeof DICT) => DICT[k]?.[lang] ?? (k as string);

  return <LanguageContext.Provider value={{ lang, setLang, t }}>{children}</LanguageContext.Provider>;
}

export const useLang = () => useContext(LanguageContext);
