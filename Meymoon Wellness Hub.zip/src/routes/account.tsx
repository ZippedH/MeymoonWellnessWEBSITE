import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/account")({
  head: () => ({
    meta: [
      { title: "Client Account — Meymoon" },
      { name: "description", content: "Your Meymoon dashboard: subscription, sessions and bookings." },
    ],
  }),
  component: AccountPage,
});

function AccountPage() {
  return (
    <div className="px-6 pb-32 pt-40 lg:px-10">
      <div className="mx-auto max-w-3xl text-center">
        <p className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">Private</p>
        <h1 className="mt-4 font-serif text-5xl md:text-6xl">Client Account</h1>
        <p className="mt-6 text-base text-muted-foreground">
          Your personal dashboard arrives in the next step.
        </p>
        <Link to="/" className="mt-12 inline-block text-[11px] uppercase tracking-[0.28em] hover:underline underline-offset-8">
          ← Back home
        </Link>
      </div>
    </div>
  );
}
