import { createFileRoute } from "@tanstack/react-router";
import { MapPin, Phone, Clock, MessageCircle, ArrowUpRight } from "lucide-react";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Meymoon" },
      { name: "description", content: "Vizitează Meymoon Studio pe Strada Rodiei 57, București. Rezervări prin telefon sau WhatsApp." },
      { property: "og:title", content: "Contact — Meymoon Studio" },
      { property: "og:description", content: "Strada Rodiei 57, București. WhatsApp, telefon și program complet." },
    ],
  }),
  component: ContactPage,
});

const ADDRESS = "Strada Rodiei 57, București 030955, România";
const PHONE = "+40 751 901 111";
const PHONE_RAW = "40751901111";
const MAPS_QUERY = encodeURIComponent("Strada Rodiei 57, Bucharest 030955, Romania");

function ContactPage() {
  const { t } = useLang();

  return (
    <div className="px-6 pb-32 pt-40 lg:px-10">
      <div className="mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center">
          <p className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">{t("contact.eyebrow")}</p>
          <h1 className="mt-4 font-serif text-5xl md:text-6xl">{t("contact.title")}</h1>
          <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-muted-foreground">{t("contact.lead")}</p>
        </div>

        {/* Info cards */}
        <div className="mt-20 grid gap-px overflow-hidden border border-border bg-border sm:grid-cols-3">
          <div className="bg-card p-8 text-center">
            <MapPin strokeWidth={1.1} className="mx-auto h-6 w-6 text-primary" />
            <p className="mt-5 text-[10px] uppercase tracking-[0.28em] text-muted-foreground">{t("contact.address")}</p>
            <p className="mt-3 text-sm leading-relaxed text-foreground">Strada Rodiei 57<br />București 030955</p>
          </div>
          <div className="bg-card p-8 text-center">
            <Phone strokeWidth={1.1} className="mx-auto h-6 w-6 text-primary" />
            <p className="mt-5 text-[10px] uppercase tracking-[0.28em] text-muted-foreground">{t("contact.phone")}</p>
            <a href={`tel:${PHONE.replace(/\s/g, "")}`} className="mt-3 block text-sm text-foreground hover:underline underline-offset-4">{PHONE}</a>
          </div>
          <div className="bg-card p-8 text-center">
            <Clock strokeWidth={1.1} className="mx-auto h-6 w-6 text-primary" />
            <p className="mt-5 text-[10px] uppercase tracking-[0.28em] text-muted-foreground">{t("contact.hours")}</p>
            <p className="mt-3 text-sm text-foreground">07:00 – 22:00<br /><span className="text-muted-foreground">Luni – Duminică</span></p>
          </div>
        </div>

        {/* Map */}
        <div className="mt-12">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">{t("contact.findUs")}</p>
              <h2 className="mt-3 font-serif text-3xl">{ADDRESS}</h2>
            </div>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${MAPS_QUERY}`}
              target="_blank"
              rel="noreferrer noopener"
              className="hidden md:inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.28em] text-foreground hover:gap-3 transition-all"
            >
              {t("contact.directions")} <ArrowUpRight className="h-3.5 w-3.5" />
            </a>
          </div>

          <div className="relative mt-8 overflow-hidden border border-border bg-secondary/40">
            <div className="pointer-events-none absolute inset-x-0 top-0 z-10 h-px bg-border" />
            <iframe
              title="Meymoon Studio — Strada Rodiei 57, București"
              src={`https://www.google.com/maps?q=${MAPS_QUERY}&z=16&hl=ro&output=embed`}
              className="block h-[420px] w-full md:h-[520px]"
              style={{ border: 0, filter: "grayscale(15%) contrast(0.98)" }}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
            />
          </div>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <a
              href={`https://wa.me/${PHONE_RAW}`}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex items-center justify-center gap-2 border border-foreground bg-foreground px-6 py-3 text-[10px] uppercase tracking-[0.28em] text-background transition-all hover:bg-transparent hover:text-foreground"
            >
              <MessageCircle className="h-3.5 w-3.5" /> {t("contact.whatsapp")}
            </a>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${MAPS_QUERY}`}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex md:hidden items-center justify-center gap-2 border border-border px-6 py-3 text-[10px] uppercase tracking-[0.28em] hover:bg-foreground hover:text-background transition-colors"
            >
              {t("contact.directions")} <ArrowUpRight className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
