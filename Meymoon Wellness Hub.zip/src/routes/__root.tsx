import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Menu, X, Instagram, Facebook, MapPin, Phone, Clock, Globe } from "lucide-react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { LanguageProvider, useLang } from "../lib/i18n";
import { LegalModal } from "../components/LegalModal";


function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-serif text-7xl text-foreground">404</h1>
        <h2 className="mt-4 text-lg tracking-wide text-foreground">Pagină negăsită</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Pagina pe care o cauți nu există sau a fost mutată.
        </p>
        <div className="mt-8">
          <Link
            to="/"
            className="inline-flex items-center justify-center border border-foreground/80 px-6 py-3 text-xs uppercase tracking-[0.2em] text-foreground transition-colors hover:bg-foreground hover:text-background"
          >
            Înapoi acasă
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-serif text-2xl text-foreground">Pagina nu s-a încărcat</h1>
        <p className="mt-2 text-sm text-muted-foreground">A apărut o eroare. Încearcă din nou.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <button
            onClick={() => { router.invalidate(); reset(); }}
            className="border border-foreground px-6 py-3 text-xs uppercase tracking-[0.2em] hover:bg-foreground hover:text-background transition-colors"
          >
            Reîncearcă
          </button>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Meymoon — Minte • Corp • Spirit" },
      { name: "description", content: "Meymoon este un studio premium de wellness și Pilates. Reformer, Yoga, Breathwork și Sound Healing într-un spațiu senin și luminos." },
      { name: "author", content: "Meymoon Studio" },
      { property: "og:title", content: "Meymoon — Studio de Wellness și Pilates" },
      { property: "og:description", content: "Un studio boutique senin pentru Pilates, Yoga și breathwork." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600&family=Inter:wght@300;400;500;600&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="ro">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function LanguageToggle({ className = "" }: { className?: string }) {
  const { lang, setLang } = useLang();
  return (
    <button
      type="button"
      onClick={() => setLang(lang === "ro" ? "en" : "ro")}
      aria-label="Schimbă limba"
      className={`inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.28em] text-foreground/80 hover:text-foreground transition-colors ${className}`}
    >
      <Globe className="h-3.5 w-3.5" />
      <span className={lang === "ro" ? "text-foreground" : ""}>RO</span>
      <span className="text-foreground/40">/</span>
      <span className={lang === "en" ? "text-foreground" : ""}>EN</span>
    </button>
  );
}

function Navbar() {
  const { t } = useLang();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const NAV_LINKS = [
    { to: "/", label: t("nav.home") },
    { to: "/classes", label: t("nav.classes") },
    { to: "/schedule", label: t("nav.schedule") },
    { to: "/memberships", label: t("nav.memberships") },
    { to: "/contact", label: t("nav.contact") },
  ] as const;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-40 transition-all duration-500 ${
          scrolled ? "bg-background/85 backdrop-blur-md border-b border-border/60" : "bg-transparent"
        }`}
      >
        <nav className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6 lg:px-10">
          <Link to="/" className="font-serif text-2xl tracking-[0.18em] text-foreground">
            MEYMOON
          </Link>

          <button
            type="button"
            aria-label={t("nav.openMenu")}
            onClick={() => setOpen(true)}
            className="inline-flex items-center gap-3 text-foreground"
          >
            <span className="hidden sm:inline text-[10px] uppercase tracking-[0.28em] text-foreground/80">Menu</span>
            <Menu className="h-6 w-6" strokeWidth={1.4} />
          </button>
        </nav>
      </header>


      {/* Full-screen menu overlay (desktop + mobile) */}
      <div
        className={`fixed inset-0 z-50 bg-background transition-opacity duration-500 ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      >
        <div className="flex h-20 items-center justify-between px-6 lg:px-10">
          <span className="font-serif text-2xl tracking-[0.18em]">MEYMOON</span>
          <button
            aria-label={t("nav.closeMenu")}
            onClick={() => setOpen(false)}
            className="inline-flex items-center gap-3"
          >
            <span className="hidden sm:inline text-[10px] uppercase tracking-[0.28em] text-foreground/80">Close</span>
            <X className="h-6 w-6" strokeWidth={1.4} />
          </button>
        </div>

        <div className="mx-auto flex h-[calc(100vh-5rem)] max-w-4xl flex-col items-center justify-center px-6">
          <ul className="flex flex-col items-center gap-6 md:gap-8">
            {NAV_LINKS.map((l, idx) => (
              <li
                key={l.to}
                style={{ transitionDelay: `${idx * 60}ms` }}
                className={`transition-all duration-500 ${open ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
              >
                <Link
                  to={l.to}
                  onClick={() => setOpen(false)}
                  className="font-serif text-4xl md:text-5xl text-foreground hover:italic transition-all"
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>

          <div className="mt-16 flex flex-col items-center gap-6">
            <Link
              to="/account"
              onClick={() => setOpen(false)}
              className="border border-foreground px-10 py-3.5 text-[10px] uppercase tracking-[0.3em] hover:bg-foreground hover:text-background transition-all"
            >
              {t("nav.account")}
            </Link>
            <LanguageToggle />
          </div>
        </div>
      </div>
    </>
  );
}


const LEGAL_CONTENT = {
  gdpr: {
    title: "Politica GDPR",
    body: "Meymoon Studio (Operator date): Colectăm numele, email-ul, telefonul și datele de facturare exclusiv pentru crearea contului, gestionarea rezervărilor la clase și procesarea plăților prin Stripe. Datele tale sunt în siguranță și nu vor fi vândute terților.",
  },
  terms: {
    title: "Termeni și Condiții",
    body:
      "Rezervări și Anulări: Rezervarea unei clase se face exclusiv prin platformă, fiind condiționată de existența unui abonament activ. Politica de anulare este de 24 de ore. Dacă anulezi cu mai puțin de 24 de ore înainte de începerea clasei, ședința va fi considerată efectuată și va fi retrasă din abonament.\n\nValabilitate abonamente: Fiecare abonament (4, 8, 12 ședințe) are o valabilitate fixă de 30 sau 45 de zile din momentul achiziției și nu poate fi prelungit decât în cazuri medicale justificate.",
  },
  cookies: {
    title: "Politica de Cookies",
    body:
      "Site-ul Meymoon folosește cookie-uri esențiale (pentru a te menține logat în contul tău) și cookie-uri de analiză/marketing (Google Analytics, Meta Pixel) pentru a înțelege cum interacționează vizitatorii cu platforma noastră și pentru a îmbunătăți experiența. Poți accepta sau refuza cookie-urile non-esențiale prin bannerul dedicat.",
  },
} as const;

type LegalKey = keyof typeof LEGAL_CONTENT;

function Footer() {
  const { t } = useLang();
  const [legal, setLegal] = useState<LegalKey | null>(null);

  return (
    <footer className="border-t border-border bg-secondary/40">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-20 md:grid-cols-4 lg:px-10">
        <div>
          <Link
            to="/staff"
            aria-label="Staff portal"
            title="Meymoon"
            className="font-serif text-2xl tracking-[0.18em] inline-block cursor-pointer"
          >
            MEYMOON
          </Link>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{t("footer.tagline")}</p>
          <div className="mt-6 flex gap-4 text-muted-foreground">
            <a
              href="https://www.instagram.com/meymoonstudio?igsh=cGZxNm1zazF5d3pt"
              target="_blank"
              rel="noreferrer noopener"
              aria-label="Instagram"
              className="hover:text-foreground transition-colors"
            >
              <Instagram className="h-4 w-4" />
            </a>
            <a href="#" aria-label="Facebook" className="hover:text-foreground transition-colors"><Facebook className="h-4 w-4" /></a>
          </div>
        </div>

        <div>
          <h4 className="text-[10px] uppercase tracking-[0.25em] text-foreground">{t("footer.contact")}</h4>
          <ul className="mt-5 space-y-3 text-sm text-muted-foreground">
            <li className="flex gap-2"><MapPin className="mt-0.5 h-4 w-4 shrink-0" /> Strada Rodiei 57, București 030955</li>
            <li className="flex gap-2"><Phone className="mt-0.5 h-4 w-4 shrink-0" /> +40 751 901 111</li>
            <li className="flex gap-2"><Clock className="mt-0.5 h-4 w-4 shrink-0" /> {t("footer.hours")}</li>
          </ul>
        </div>

        <div>
          <h4 className="text-[10px] uppercase tracking-[0.25em] text-foreground">{t("footer.explore")}</h4>
          <ul className="mt-5 space-y-3 text-sm text-muted-foreground">
            <li><Link to="/classes" className="hover:text-foreground transition-colors">{t("nav.classes")}</Link></li>
            <li><Link to="/schedule" className="hover:text-foreground transition-colors">{t("nav.schedule")}</Link></li>
            <li><Link to="/memberships" className="hover:text-foreground transition-colors">{t("nav.memberships")}</Link></li>
            <li><Link to="/contact" className="hover:text-foreground transition-colors">{t("nav.contact")}</Link></li>
            <li><Link to="/account" className="hover:text-foreground transition-colors">{t("nav.account")}</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-[10px] uppercase tracking-[0.25em] text-foreground">{t("footer.newsletter")}</h4>
          <p className="mt-5 text-sm text-muted-foreground">{t("footer.newsletterText")}</p>
          <form
            className="mt-4 flex border border-border bg-background"
            onSubmit={(e) => e.preventDefault()}
          >
            <input
              type="email"
              placeholder={t("footer.emailPlaceholder")}
              className="w-full bg-transparent px-3 py-3 text-sm outline-none placeholder:text-muted-foreground"
            />
            <button className="px-4 text-[10px] uppercase tracking-[0.25em] hover:bg-foreground hover:text-background transition-colors">
              {t("footer.join")}
            </button>
          </form>
        </div>
      </div>

      <div className="border-t border-border/70">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-6 py-6 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between lg:px-10">
          <span>© {new Date().getFullYear()} Meymoon Studio · by LaunchLabz</span>
          <div className="flex gap-6">
            <button type="button" onClick={() => setLegal("gdpr")} className="hover:text-foreground transition-colors">{t("footer.gdpr")}</button>
            <button type="button" onClick={() => setLegal("terms")} className="hover:text-foreground transition-colors">{t("footer.terms")}</button>
            <button type="button" onClick={() => setLegal("cookies")} className="hover:text-foreground transition-colors">{t("footer.cookies")}</button>
          </div>
        </div>
      </div>

      {legal && (
        <LegalModal title={LEGAL_CONTENT[legal].title} onClose={() => setLegal(null)}>
          {LEGAL_CONTENT[legal].body}
        </LegalModal>
      )}
    </footer>
  );
}


function CookieBanner() {
  const { t } = useLang();
  const [show, setShow] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!localStorage.getItem("meymoon-cookies")) setShow(true);
  }, []);
  if (!show) return null;
  return (
    <div className="fixed inset-x-4 bottom-4 z-40 mx-auto max-w-3xl border border-border bg-background/95 backdrop-blur-md shadow-lg">
      <div className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs leading-relaxed text-muted-foreground">{t("cookie.text")}</p>
        <div className="flex gap-3">
          <button
            onClick={() => { localStorage.setItem("meymoon-cookies", "declined"); setShow(false); }}
            className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground hover:text-foreground"
          >
            {t("cookie.decline")}
          </button>
          <button
            onClick={() => { localStorage.setItem("meymoon-cookies", "accepted"); setShow(false); }}
            className="border border-foreground px-5 py-2.5 text-[10px] uppercase tracking-[0.25em] hover:bg-foreground hover:text-background transition-colors"
          >
            {t("cookie.accept")}
          </button>
        </div>
      </div>
    </div>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <div className="flex min-h-screen flex-col bg-background text-foreground">
          <Navbar />
          <main className="flex-1 fade-in">
            <Outlet />
          </main>
          <Footer />
          <CookieBanner />
        </div>
      </LanguageProvider>
    </QueryClientProvider>
  );
}
