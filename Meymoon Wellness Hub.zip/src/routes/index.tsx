import { createFileRoute, Link } from "@tanstack/react-router";
import { Sun, Wind, Sparkles, Leaf, ArrowRight, Star, Send } from "lucide-react";
import { useState } from "react";
import { useLang } from "@/lib/i18n";
import { StudioMap } from "@/components/StudioMap";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Meymoon — Minte • Corp • Spirit" },
      { name: "description", content: "Studio premium de wellness și Pilates într-un spațiu senin, scăldat în lumină." },
      { property: "og:title", content: "Meymoon — Studio de Wellness și Pilates" },
      { property: "og:description", content: "Un studio boutique senin pentru Pilates, Yoga și breathwork." },
      { property: "og:image", content: "https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=1600&q=80" },
    ],
  }),
  component: Home,
});

const BENEFITS = [
  { icon: Sun, tk: "ben.light.t", xk: "ben.light.x" },
  { icon: Leaf, tk: "ben.org.t", xk: "ben.org.x" },
  { icon: Wind, tk: "ben.mind.t", xk: "ben.mind.x" },
  { icon: Sparkles, tk: "ben.amen.t", xk: "ben.amen.x" },
] as const;

const INSTRUCTORS = [
  { name: "Ana Maria", role: { ro: "Reformer & Postură", en: "Reformer & Postural" }, img: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=80" },
  { name: "Ioana", role: { ro: "Yoga & Breathwork", en: "Yoga & Breathwork" }, img: "https://images.unsplash.com/photo-1499714608240-22fc6ad53fb2?auto=format&fit=crop&w=600&q=80" },
  { name: "Sofia", role: { ro: "Sound Healing", en: "Sound Healing" }, img: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=600&q=80" },
];

const SEED_REVIEWS = [
  { name: "Elena V.", rating: 5, text: { ro: "Un spațiu care te primește cald. Ies de la fiecare clasă mai ușoară.", en: "A space that welcomes you warmly. I leave every class lighter." } },
  { name: "Mara P.", rating: 5, text: { ro: "Instructori atenți la detaliu și o atmosferă de un rafinament rar.", en: "Attentive instructors and a rare, refined atmosphere." } },
  { name: "Ioana R.", rating: 5, text: { ro: "Cel mai frumos ritual al săptămânii mele.", en: "The most beautiful ritual of my week." } },
];

function Home() {
  const { t, lang } = useLang();
  const [reviews, setReviews] = useState(SEED_REVIEWS);
  const [rName, setRName] = useState("");
  const [rText, setRText] = useState("");
  const [rRating, setRRating] = useState(5);

  const submitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rName.trim() || !rText.trim()) return;
    setReviews([{ name: rName.trim(), rating: rRating, text: { ro: rText.trim(), en: rText.trim() } }, ...reviews]);
    setRName(""); setRText(""); setRRating(5);
  };

  return (
    <div className="overflow-hidden">
      {/* HERO */}
      <section className="relative flex min-h-[100svh] items-center justify-center text-center">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=2000&q=80"
            alt="Interior luminat de soare al studioului Pilates"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/20 to-background/80" />
        </div>

        <div className="relative z-10 mx-auto max-w-3xl px-6 fade-in-up">
          <h1 className="mt-8 font-serif text-5xl leading-[1.05] text-foreground sm:text-6xl md:text-8xl">
            Meymoon
            <span className="mt-2 block text-2xl tracking-[0.35em] sm:text-3xl md:text-4xl">
              {t("home.subtitle")}
            </span>
          </h1>
          <p className="mx-auto mt-8 max-w-xl text-sm leading-relaxed text-foreground/80 md:text-base">
            {t("home.heroLead")}
          </p>
          <div className="mt-12 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              to="/schedule"
              className="group inline-flex items-center gap-3 border border-foreground bg-foreground px-8 py-4 text-[11px] uppercase tracking-[0.28em] text-background transition-all hover:bg-transparent hover:text-foreground"
            >
              {t("home.bookFirst")}
              <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              to="/classes"
              className="text-[11px] uppercase tracking-[0.28em] text-foreground/80 underline-offset-8 hover:underline"
            >
              {t("home.exploreClasses")}
            </Link>
          </div>
        </div>
      </section>

      {/* BENEFITS */}
      <section className="border-y border-border bg-secondary/30 px-6 py-28 md:py-36 lg:px-10">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <p className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">{t("home.studio")}</p>
            <h2 className="mt-4 font-serif text-3xl md:text-4xl">{t("home.craftedForStillness")}</h2>
          </div>
          <div className="mt-20 grid gap-12 sm:grid-cols-2 lg:grid-cols-4">
            {BENEFITS.map((b) => (
              <div key={b.tk} className="text-center">
                <b.icon strokeWidth={1} className="mx-auto h-10 w-10 text-primary" />
                <h3 className="mt-6 font-serif text-xl">{t(b.tk)}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{t(b.xk)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INSTRUCTORS */}
      <section className="bg-secondary/40 px-6 py-32 md:py-44 lg:px-10">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <p className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">{t("home.instructors")}</p>
            <h2 className="mt-4 font-serif text-4xl md:text-5xl">{t("home.guided")}</h2>
          </div>
          <div className="mt-16 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
            {INSTRUCTORS.map((i) => (
              <div key={i.name} className="group">
                <div className="aspect-[3/4] overflow-hidden bg-muted">
                  <img src={i.img} alt={i.name} className="h-full w-full object-cover grayscale transition-all duration-700 group-hover:grayscale-0" />
                </div>
                <h3 className="mt-6 font-serif text-2xl">{i.name}</h3>
                <p className="mt-1 text-[11px] uppercase tracking-[0.25em] text-muted-foreground">{i.role[lang]}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* REVIEWS (compact) */}
      <section className="px-6 py-20 md:py-24 lg:px-10">
        <div className="mx-auto max-w-4xl">
          <div className="text-center">
            <p className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">{t("home.reviews")}</p>
            <h2 className="mt-3 font-serif text-2xl md:text-3xl">{t("home.reviewsTitle")}</h2>
          </div>

          <div className="mt-10 grid gap-4 sm:grid-cols-3">
            {reviews.slice(0, 6).map((r, i) => (
              <div key={i} className="border border-border bg-background/60 p-5">
                <div className="flex gap-0.5 text-primary">
                  {Array.from({ length: r.rating }).map((_, k) => (
                    <Star key={k} className="h-3 w-3 fill-current" strokeWidth={0} />
                  ))}
                </div>
                <p className="mt-3 text-xs leading-relaxed text-foreground/85">“{r.text[lang]}”</p>
                <p className="mt-3 text-[10px] uppercase tracking-[0.25em] text-muted-foreground">— {r.name}</p>
              </div>
            ))}
          </div>

          <form onSubmit={submitReview} className="mx-auto mt-10 max-w-xl border border-border bg-background/60 p-5">
            <p className="text-[10px] uppercase tracking-[0.28em] text-muted-foreground">{t("home.leaveReview")}</p>
            <div className="mt-3 flex flex-col gap-3">
              <input
                value={rName}
                onChange={(e) => setRName(e.target.value)}
                placeholder={t("home.yourName")}
                className="w-full border border-border bg-transparent px-3 py-2 text-sm outline-none"
              />
              <textarea
                value={rText}
                onChange={(e) => setRText(e.target.value)}
                placeholder={t("home.yourReview")}
                rows={2}
                className="w-full resize-none border border-border bg-transparent px-3 py-2 text-sm outline-none"
              />
              <div className="flex items-center justify-between">
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setRRating(n)}
                      aria-label={`${n} stele`}
                      className="text-primary"
                    >
                      <Star className={`h-4 w-4 ${n <= rRating ? "fill-current" : ""}`} strokeWidth={1.2} />
                    </button>
                  ))}
                </div>
                <button
                  type="submit"
                  className="border border-foreground px-5 py-2 text-[10px] uppercase tracking-[0.28em] hover:bg-foreground hover:text-background transition-colors"
                >
                  {t("home.publish")}
                </button>
              </div>
            </div>
          </form>
        </div>
      </section>

      {/* MAP */}
      <section className="border-t border-border bg-background px-6 py-28 md:py-36 lg:px-10">
        <div className="mx-auto max-w-6xl">
          <StudioMap eyebrow={t("home.visitUs")} title={t("home.mapTitle")} />
        </div>
      </section>

      {/* BIG NEWSLETTER */}
      <section className="relative overflow-hidden border-t border-border">
        <img
          src="https://images.unsplash.com/photo-1545389336-cf090694435e?auto=format&fit=crop&w=2000&q=80"
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-background/85 backdrop-blur-sm" />
        <div className="relative mx-auto max-w-4xl px-6 py-32 text-center md:py-44">
          <p className="text-[10px] uppercase tracking-[0.5em] text-muted-foreground">{t("home.newsletterEyebrow")}</p>
          <h2 className="mt-6 font-serif text-5xl leading-tight text-foreground md:text-7xl">
            {t("home.newsletterTitle")}
          </h2>
          <p className="mx-auto mt-6 max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base">
            {t("home.newsletterText")}
          </p>
          <form
            onSubmit={(e) => e.preventDefault()}
            className="mx-auto mt-12 flex max-w-xl flex-col gap-3 sm:flex-row sm:items-stretch"
          >
            <input
              type="email"
              required
              placeholder={t("footer.emailPlaceholder")}
              className="w-full border border-border bg-background/80 px-5 py-4 text-sm outline-none placeholder:text-muted-foreground focus:border-foreground transition-colors"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-2 border border-foreground bg-foreground px-8 py-4 text-[11px] uppercase tracking-[0.28em] text-background hover:bg-transparent hover:text-foreground transition-all"
            >
              <Send className="h-3.5 w-3.5" />
              {t("footer.join")}
            </button>
          </form>
          <p className="mt-6 text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
            {t("home.newsletterNote")}
          </p>
        </div>
      </section>
    </div>
  );
}
