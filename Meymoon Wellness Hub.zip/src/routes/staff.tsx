import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  LayoutDashboard,
  Dumbbell,
  CalendarDays,
  MapPin,
  Mail,
  LogOut,
  Plus,
  Pencil,
  Archive,
  Send,
  X,
  Lock,
  Users,
  CheckCircle2,
  Trash2,
  Bold,
  Italic,
  Underline,
  Link2,
  List,
  UserCog,
  Sparkles,
  ClipboardList,
} from "lucide-react";
import { ImageUpload } from "@/components/ImageUpload";


export const Route = createFileRoute("/staff")({
  head: () => ({ meta: [{ title: "Meymoon · Staff Portal" }, { name: "robots", content: "noindex" }] }),
  component: StaffPortal,
});

const PASSWORD = "llbz2026";
const STORAGE_KEY = "meymoon-staff-auth";

type TabId = "dashboard" | "classes" | "schedule" | "staff" | "events" | "reservations" | "location" | "newsletter";

type Reservation = {
  id: string;
  clientName: string;
  clientEmail: string;
  className: string;
  instructor: string;
  date: string;
  time: string;
  status: "Confirmată" | "În așteptare" | "Anulată";
};

const INITIAL_RESERVATIONS: Reservation[] = [
  { id: "r1", clientName: "Elena Popescu", clientEmail: "elena.p@email.com", className: "Pilates Reformer", instructor: "Ana Maria", date: "2026-07-05", time: "09:00", status: "Confirmată" },
  { id: "r2", clientName: "Maria Ionescu", clientEmail: "maria.i@email.com", className: "Yoga Flow", instructor: "Ioana", date: "2026-07-05", time: "10:30", status: "Confirmată" },
  { id: "r3", clientName: "Andreea Vasilescu", clientEmail: "andreea.v@email.com", className: "Sound Healing", instructor: "Sofia", date: "2026-07-05", time: "18:00", status: "În așteptare" },
  { id: "r4", clientName: "Cristina Dumitrescu", clientEmail: "cristina.d@email.com", className: "Breathwork", instructor: "Ioana", date: "2026-07-06", time: "08:00", status: "Confirmată" },
  { id: "r5", clientName: "Laura Marinescu", clientEmail: "laura.m@email.com", className: "Pilates Mat", instructor: "Ana Maria", date: "2026-07-06", time: "11:00", status: "Anulată" },
  { id: "r6", clientName: "Diana Stoica", clientEmail: "diana.s@email.com", className: "Pilates Reformer", instructor: "Ana Maria", date: "2026-07-07", time: "19:00", status: "Confirmată" },
];

type ClassItem = {
  id: string;
  title: string;
  description: string;
  benefits: string;
  level: "Beginner" | "Intermediate" | "Advanced";
  duration: number;
  image?: string;
  archived?: boolean;
};

type Session = {
  id: string;
  classId: string;
  instructor: string;
  date: string;
  time: string;
  capacity: number;
  booked: number;
};

type Newsletter = { id: string; subject: string; sentAt: string; status: "Sent" | "Failed"; recipients: number; preview: string };

type StaffMember = {
  id: string;
  name: string;
  role: string;
  email: string;
  phone?: string;
  photo?: string;
  active: boolean;
};

type EventItem = {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  image?: string;
};


const INITIAL_CLASSES: ClassItem[] = [];

const INITIAL_SESSIONS: Session[] = [];

const INITIAL_NEWSLETTERS: Newsletter[] = [
  { id: "n1", subject: "Seria nouă Reformer — Septembrie", sentAt: "2026-06-12", status: "Sent", recipients: 1186, preview: "Bun venit toamna." },
  { id: "n2", subject: "Sound Healing · Ediția Lună Plină", sentAt: "2026-05-23", status: "Sent", recipients: 1140, preview: "O seară de vibrație." },
];

const INITIAL_STAFF: StaffMember[] = [
  { id: "u1", name: "Ana Maria", role: "Reformer & Postură", email: "ana@meymoon.ro", phone: "+40 751 901 111", active: true },
  { id: "u2", name: "Ioana", role: "Yoga & Breathwork", email: "ioana@meymoon.ro", active: true },
  { id: "u3", name: "Sofia", role: "Sound Healing", email: "sofia@meymoon.ro", active: true },
];

function StaffPortal() {
  const [authed, setAuthed] = useState(false);
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");

  // Security: never persist auth. Require password on every visit, on tab
  // hide/return, and clear when leaving the portal.
  useEffect(() => {
    if (typeof window === "undefined") return;
    try { sessionStorage.removeItem(STORAGE_KEY); localStorage.removeItem(STORAGE_KEY); } catch {}
    const lockOnHide = () => { if (document.visibilityState === "hidden") { setAuthed(true ? false : false); setAuthed(false); setPw(""); } };
    const lockOnLeave = () => { setAuthed(false); setPw(""); };
    document.addEventListener("visibilitychange", lockOnHide);
    window.addEventListener("pagehide", lockOnLeave);
    window.addEventListener("beforeunload", lockOnLeave);
    return () => {
      document.removeEventListener("visibilitychange", lockOnHide);
      window.removeEventListener("pagehide", lockOnLeave);
      window.removeEventListener("beforeunload", lockOnLeave);
      setAuthed(false);
      setPw("");
    };
  }, []);

  if (!authed) {
    return (
      <div className="flex min-h-[calc(100vh-5rem)] items-center justify-center px-6 py-24">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (pw === PASSWORD) {
              setAuthed(true);
              setPw("");
            } else setErr("Parolă incorectă");
          }}
          className="w-full max-w-md border border-border bg-card p-10"
        >
          <Lock className="h-6 w-6 text-primary" strokeWidth={1.2} />
          <h1 className="mt-6 font-serif text-3xl">Staff Portal</h1>
          <p className="mt-2 text-sm text-muted-foreground">Acces privat pentru echipa Meymoon.</p>
          <label className="mt-8 block text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Parolă</label>
          <input
            type="password"
            autoFocus
            value={pw}
            onChange={(e) => { setPw(e.target.value); setErr(""); }}
            className="mt-2 w-full border border-border bg-background px-4 py-3 text-sm outline-none focus:border-foreground"
          />
          {err && <p className="mt-3 text-xs text-destructive">{err}</p>}
          <button className="mt-6 w-full border border-foreground bg-foreground px-6 py-3 text-[11px] uppercase tracking-[0.28em] text-background hover:bg-transparent hover:text-foreground transition-all">
            Intră
          </button>
        </form>
      </div>
    );
  }

  return <Portal onLogout={() => { sessionStorage.removeItem(STORAGE_KEY); setAuthed(false); }} />;
}

function Portal({ onLogout }: { onLogout: () => void }) {
  const [tab, setTab] = useState<TabId>("dashboard");
  const [classes, setClasses] = useState<ClassItem[]>(INITIAL_CLASSES);
  const [sessions, setSessions] = useState<Session[]>(INITIAL_SESSIONS);
  const [newsletters, setNewsletters] = useState<Newsletter[]>(INITIAL_NEWSLETTERS);
  const [staff, setStaff] = useState<StaffMember[]>(INITIAL_STAFF);
  const [events, setEvents] = useState<EventItem[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>(INITIAL_RESERVATIONS);
  const [navHidden, setNavHidden] = useState(false);
  const subscribers = 1240;

  const nav: { id: TabId; label: string; icon: typeof LayoutDashboard }[] = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "classes", label: "Class Manager", icon: Dumbbell },
    { id: "schedule", label: "Program", icon: CalendarDays },
    { id: "reservations", label: "Rezervări", icon: ClipboardList },
    { id: "staff", label: "Staff", icon: UserCog },
    { id: "events", label: "Evenimente", icon: Sparkles },
    { id: "location", label: "Locație", icon: MapPin },
    { id: "newsletter", label: "Newsletter", icon: Mail },
  ];


  return (
    <div className="flex min-h-[calc(100vh-5rem)] bg-secondary/30">
      {/* Sidebar */}
      {!navHidden && (
        <aside className="hidden md:flex w-64 flex-col border-r border-border bg-background">
          <div className="px-8 py-8">
            <div className="font-serif text-xl tracking-[0.18em]">MEYMOON</div>
            <p className="mt-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Staff Portal</p>
          </div>
          <nav className="flex-1 px-4">
            {nav.map((n) => (
              <button
                key={n.id}
                onClick={() => setTab(n.id)}
                className={`mb-1 flex w-full items-center gap-3 px-4 py-3 text-sm transition-colors ${
                  tab === n.id ? "bg-foreground text-background" : "text-foreground/80 hover:bg-secondary"
                }`}
              >
                <n.icon className="h-4 w-4" strokeWidth={1.4} />
                {n.label}
              </button>
            ))}
          </nav>
          <button
            onClick={onLogout}
            className="m-4 flex items-center justify-center gap-2 border border-border px-4 py-3 text-[10px] uppercase tracking-[0.25em] hover:bg-foreground hover:text-background transition-colors"
          >
            <LogOut className="h-3.5 w-3.5" /> Ieșire
          </button>
        </aside>
      )}

      {/* Mobile tabs */}
      {!navHidden && (
        <div className="md:hidden fixed inset-x-0 top-20 z-30 flex gap-1 overflow-x-auto border-b border-border bg-background px-3 py-2">
          {nav.map((n) => (
            <button
              key={n.id}
              onClick={() => setTab(n.id)}
              className={`shrink-0 px-3 py-2 text-[10px] uppercase tracking-[0.2em] ${
                tab === n.id ? "bg-foreground text-background" : "text-foreground/70"
              }`}
            >
              {n.label}
            </button>
          ))}
        </div>
      )}

      <main className={`flex-1 overflow-auto px-6 py-10 md:px-12 md:py-12 ${navHidden ? "pt-10" : "pt-24 md:pt-12"}`}>
        {tab === "dashboard" && <Dashboard classes={classes} sessions={sessions} subscribers={subscribers} staff={staff} />}
        {tab === "classes" && <ClassManager classes={classes} setClasses={setClasses} onFormOpenChange={setNavHidden} />}
        {tab === "schedule" && <ScheduleManager classes={classes} sessions={sessions} setSessions={setSessions} />}
        {tab === "reservations" && <ReservationsManager reservations={reservations} setReservations={setReservations} />}
        {tab === "staff" && <StaffManager staff={staff} setStaff={setStaff} />}
        {tab === "events" && <EventsManager events={events} setEvents={setEvents} />}

        {tab === "location" && <LocationSettings />}
        {tab === "newsletter" && (
          <NewsletterBroadcast subscribers={subscribers} newsletters={newsletters} setNewsletters={setNewsletters} />
        )}
      </main>
    </div>
  );
}

/* ---------- Dashboard ---------- */
function Dashboard({ classes, sessions, subscribers, staff }: { classes: ClassItem[]; sessions: Session[]; subscribers: number; staff: StaffMember[] }) {
  const today = new Date().toISOString().slice(0, 10);
  const todays = sessions.filter((s) => s.date === today).sort((a, b) => a.time.localeCompare(b.time));
  const bookings = todays.reduce((sum, s) => sum + s.booked, 0);

  const stats = [
    { label: "Clase active", value: String(classes.filter((c) => !c.archived).length), icon: Dumbbell },
    { label: "Rezervări azi", value: String(bookings), icon: CheckCircle2 },
    { label: "Membri staff", value: String(staff.filter((s) => s.active).length), icon: Users },
    { label: "Abonați", value: subscribers.toLocaleString(), icon: Mail },
  ];

  return (
    <div className="max-w-6xl">
      <PageHeader title="Dashboard" subtitle="O privire de ansamblu asupra studioului tău." />
      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="border border-border bg-card p-6">
            <s.icon className="h-5 w-5 text-primary" strokeWidth={1.3} />
            <div className="mt-6 font-serif text-4xl">{s.value}</div>
            <div className="mt-2 text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="mt-12 border border-border bg-card">
        <div className="border-b border-border px-6 py-4">
          <h3 className="font-serif text-xl">Timeline-ul zilei</h3>
        </div>
        <ul className="divide-y divide-border">
          {todays.length === 0 && <li className="px-6 py-8 text-sm text-muted-foreground">Nicio sesiune programată.</li>}
          {todays.map((s) => {
            const c = classes.find((x) => x.id === s.classId);
            const full = s.booked >= s.capacity;
            return (
              <li key={s.id} className="flex items-center gap-6 px-6 py-5">
                <div className="w-16 font-serif text-2xl">{s.time}</div>
                <div className="flex-1">
                  <div className="font-medium">{c?.title}</div>
                  <div className="text-xs text-muted-foreground">cu {s.instructor}</div>
                </div>
                <div className={`text-[10px] uppercase tracking-[0.2em] ${full ? "text-destructive" : "text-primary"}`}>
                  {s.booked}/{s.capacity} {full ? "Full" : "Liber"}
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

/* ---------- Class Manager ---------- */
function ClassManager({ classes, setClasses, onFormOpenChange }: { classes: ClassItem[]; setClasses: (v: ClassItem[]) => void; onFormOpenChange?: (open: boolean) => void }) {
  const [editing, setEditing] = useState<ClassItem | null>(null);
  const [open, setOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  useEffect(() => {
    onFormOpenChange?.(open);
    return () => onFormOpenChange?.(false);
  }, [open, onFormOpenChange]);

  const openForm = (item: ClassItem | null) => { setEditing(item); setOpen(true); };
  const closeForm = () => { setOpen(false); setEditing(null); };

  const save = (c: ClassItem) => {
    if (classes.find((x) => x.id === c.id)) setClasses(classes.map((x) => (x.id === c.id ? c : x)));
    else setClasses([...classes, c]);
    closeForm();
  };

  const remove = (id: string) => {
    setClasses(classes.filter((x) => x.id !== id));
    setConfirmDelete(null);
  };

  return (
    <div className="max-w-6xl">
      <div className="flex items-end justify-between">
        <PageHeader title="Class Manager" subtitle="Creează și curatoriază oferta studioului." />
        <button
          onClick={() => { setEditing(null); setOpen(true); }}
          className="inline-flex items-center gap-2 border border-foreground bg-foreground px-5 py-3 text-[10px] uppercase tracking-[0.25em] text-background hover:bg-transparent hover:text-foreground transition-all"
        >
          <Plus className="h-3.5 w-3.5" /> Clasă nouă
        </button>
      </div>

      <div className="mt-10 border border-border bg-card">
        {classes.length === 0 ? (
          <div className="px-6 py-16 text-center">
            <Dumbbell strokeWidth={1} className="mx-auto h-8 w-8 text-muted-foreground" />
            <p className="mt-4 font-serif text-xl">Nu există clase încă</p>
            <p className="mt-2 text-sm text-muted-foreground">Adaugă prima clasă pentru a o publica în studio.</p>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead className="border-b border-border text-left text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              <tr>
                <th className="px-6 py-4 font-normal w-24">Imagine</th>
                <th className="px-6 py-4 font-normal">Titlu</th>
                <th className="px-6 py-4 font-normal">Nivel</th>
                <th className="px-6 py-4 font-normal">Durată</th>
                <th className="px-6 py-4 font-normal">Status</th>
                <th className="px-6 py-4 font-normal text-right">Acțiuni</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {classes.map((c) => (
                <tr key={c.id} className={c.archived ? "opacity-50" : ""}>
                  <td className="px-6 py-4">
                    {c.image ? (
                      <img src={c.image} alt={c.title} className="h-14 w-20 object-cover border border-border" />
                    ) : (
                      <div className="h-14 w-20 border border-dashed border-border bg-secondary/40" />
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="font-medium">{c.title}</div>
                    <div className="text-xs text-muted-foreground">{c.description}</div>
                  </td>

                  <td className="px-6 py-4">{c.level}</td>
                  <td className="px-6 py-4">{c.duration} min</td>
                  <td className="px-6 py-4 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                    {c.archived ? "Arhivat" : "Activ"}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button
                      onClick={() => { setEditing(c); setOpen(true); }}
                      className="mr-3 inline-flex items-center gap-1 text-xs text-foreground/80 hover:text-foreground"
                    >
                      <Pencil className="h-3 w-3" /> Editează
                    </button>
                    <button
                      onClick={() => setClasses(classes.map((x) => (x.id === c.id ? { ...x, archived: !x.archived } : x)))}
                      className="mr-3 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
                    >
                      <Archive className="h-3 w-3" /> {c.archived ? "Restaurează" : "Arhivează"}
                    </button>
                    <button
                      onClick={() => setConfirmDelete(c.id)}
                      className="inline-flex items-center gap-1 text-xs text-destructive/80 hover:text-destructive"
                    >
                      <Trash2 className="h-3 w-3" /> Șterge
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {open && <ClassForm initial={editing} onClose={() => setOpen(false)} onSave={save} />}
      {confirmDelete && (
        <ConfirmDialog
          title="Șterge clasa"
          message="Această acțiune este permanentă. Clasa va fi eliminată definitiv."
          onCancel={() => setConfirmDelete(null)}
          onConfirm={() => remove(confirmDelete)}
        />
      )}
    </div>
  );
}

function ClassForm({
  initial,
  onClose,
  onSave,
}: {
  initial: ClassItem | null;
  onClose: () => void;
  onSave: (c: ClassItem) => void;
}) {
  const [form, setForm] = useState<ClassItem>(
    initial ?? { id: `c${Date.now()}`, title: "", description: "", benefits: "", level: "Beginner", duration: 50 },
  );
  const [err, setErr] = useState("");

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="flex-1 bg-foreground/40" onClick={onClose} />
      <div className="w-full max-w-lg overflow-y-auto bg-background p-10 shadow-2xl animate-in slide-in-from-right">
        <div className="flex items-center justify-between">
          <h3 className="font-serif text-2xl">{initial ? "Editează clasa" : "Clasă nouă"}</h3>
          <button onClick={onClose}><X className="h-5 w-5" /></button>
        </div>
        <form
          className="mt-8 space-y-5"
          onSubmit={(e) => {
            e.preventDefault();
            if (!form.title.trim()) return setErr("Titlul este obligatoriu");
            if (form.duration <= 0) return setErr("Durata trebuie să fie pozitivă");
            onSave(form);
          }}
        >
          <Field label="Titlu clasă">
            <input
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="w-full border border-border bg-background px-4 py-3 text-sm outline-none focus:border-foreground"
            />
          </Field>
          <Field label="Descriere">
            <textarea
              rows={3}
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full border border-border bg-background px-4 py-3 text-sm outline-none focus:border-foreground"
            />
          </Field>
          <Field label="Beneficii">
            <input
              value={form.benefits}
              onChange={(e) => setForm({ ...form, benefits: e.target.value })}
              className="w-full border border-border bg-background px-4 py-3 text-sm outline-none focus:border-foreground"
            />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Dificultate">
              <select
                value={form.level}
                onChange={(e) => setForm({ ...form, level: e.target.value as ClassItem["level"] })}
                className="w-full border border-border bg-background px-4 py-3 text-sm"
              >
                <option>Beginner</option>
                <option>Intermediate</option>
                <option>Advanced</option>
              </select>
            </Field>
            <Field label="Durată (min)">
              <input
                type="number"
                value={form.duration}
                onChange={(e) => setForm({ ...form, duration: +e.target.value })}
                className="w-full border border-border bg-background px-4 py-3 text-sm outline-none focus:border-foreground"
              />
            </Field>
          </div>
          <Field label="Imagine clasă">
            <ImageUpload
              value={form.image}
              onChange={(v) => setForm({ ...form, image: v })}
              label="Trage imaginea clasei aici · sau apasă pentru upload"
            />
          </Field>

          {err && <p className="text-xs text-destructive">{err}</p>}
          <button className="w-full border border-foreground bg-foreground px-6 py-3 text-[11px] uppercase tracking-[0.28em] text-background hover:bg-transparent hover:text-foreground transition-all">
            Salvează clasa
          </button>
        </form>
      </div>
    </div>
  );
}

/* ---------- Schedule ---------- */
function ScheduleManager({
  classes,
  sessions,
  setSessions,
}: {
  classes: ClassItem[];
  sessions: Session[];
  setSessions: (v: Session[]) => void;
}) {
  const [form, setForm] = useState<Omit<Session, "id" | "booked">>({
    classId: classes[0]?.id ?? "",
    instructor: "",
    date: new Date().toISOString().slice(0, 10),
    time: "09:00",
    capacity: 10,
  });
  const [err, setErr] = useState("");

  const grouped = useMemo(() => {
    const map = new Map<string, Session[]>();
    sessions.forEach((s) => {
      if (!map.has(s.date)) map.set(s.date, []);
      map.get(s.date)!.push(s);
    });
    return Array.from(map.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [sessions]);

  return (
    <div className="max-w-6xl">
      <PageHeader title="Program & Sesiuni" subtitle="Planifică sesiuni, asignează instructori, gestionează capacitatea." />

      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_360px]">
        <div className="space-y-8">
          {grouped.length === 0 && (
            <div className="border border-border bg-card px-6 py-16 text-center text-sm text-muted-foreground">
              Nicio sesiune încă. Adaugă una din partea dreaptă.
            </div>
          )}
          {grouped.map(([date, list]) => (
            <div key={date} className="border border-border bg-card">
              <div className="border-b border-border px-6 py-4 font-serif text-lg">{date}</div>
              <ul className="divide-y divide-border">
                {list.sort((a, b) => a.time.localeCompare(b.time)).map((s) => {
                  const c = classes.find((x) => x.id === s.classId);
                  const full = s.booked >= s.capacity;
                  return (
                    <li key={s.id} className="flex items-center gap-6 px-6 py-4">
                      <span className="w-16 font-mono text-sm">{s.time}</span>
                      <div className="flex-1">
                        <div className="text-sm font-medium">{c?.title}</div>
                        <div className="text-xs text-muted-foreground">{s.instructor}</div>
                      </div>
                      <span
                        className={`px-3 py-1 text-[10px] uppercase tracking-[0.2em] ${
                          full ? "bg-destructive/15 text-destructive" : "bg-primary/15 text-primary"
                        }`}
                      >
                        {s.booked}/{s.capacity}
                      </span>
                      <button
                        onClick={() => setSessions(sessions.filter((x) => x.id !== s.id))}
                        className="text-muted-foreground hover:text-destructive"
                        aria-label="Șterge sesiunea"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!form.classId) return setErr("Selectează o clasă");
            if (!form.instructor.trim()) return setErr("Instructor obligatoriu");
            if (!form.time) return setErr("Ora obligatorie");
            if (form.capacity <= 0) return setErr("Capacitatea trebuie pozitivă");
            setSessions([...sessions, { ...form, id: `s${Date.now()}`, booked: 0 }]);
            setErr("");
          }}
          className="h-fit border border-border bg-card p-6 space-y-4"
        >
          <h3 className="font-serif text-xl">Sesiune nouă</h3>
          <Field label="Clasă">
            <select
              value={form.classId}
              onChange={(e) => setForm({ ...form, classId: e.target.value })}
              className="w-full border border-border bg-background px-4 py-3 text-sm"
            >
              <option value="">— Selectează —</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>{c.title}</option>
              ))}
            </select>
          </Field>
          <Field label="Instructor">
            <input
              value={form.instructor}
              onChange={(e) => setForm({ ...form, instructor: e.target.value })}
              className="w-full border border-border bg-background px-4 py-3 text-sm"
            />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Dată">
              <input
                type="date"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full border border-border bg-background px-4 py-3 text-sm"
              />
            </Field>
            <Field label="Ora">
              <input
                type="time"
                value={form.time}
                onChange={(e) => setForm({ ...form, time: e.target.value })}
                className="w-full border border-border bg-background px-4 py-3 text-sm"
              />
            </Field>
          </div>
          <Field label="Capacitate maximă">
            <input
              type="number"
              value={form.capacity}
              onChange={(e) => setForm({ ...form, capacity: +e.target.value })}
              className="w-full border border-border bg-background px-4 py-3 text-sm"
            />
          </Field>
          {err && <p className="text-xs text-destructive">{err}</p>}
          <button className="w-full border border-foreground bg-foreground px-6 py-3 text-[11px] uppercase tracking-[0.28em] text-background hover:bg-transparent hover:text-foreground transition-all">
            Adaugă sesiune
          </button>
        </form>
      </div>
    </div>
  );
}

/* ---------- Staff Manager ---------- */
function StaffManager({ staff, setStaff }: { staff: StaffMember[]; setStaff: (v: StaffMember[]) => void }) {
  const [form, setForm] = useState<Omit<StaffMember, "id" | "active">>({ name: "", role: "", email: "", phone: "", photo: undefined });
  const [err, setErr] = useState("");
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const add = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) return setErr("Numele este obligatoriu");
    if (!form.role.trim()) return setErr("Rolul este obligatoriu");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) return setErr("Email invalid");
    setStaff([...staff, { ...form, id: `u${Date.now()}`, active: true }]);
    setForm({ name: "", role: "", email: "", phone: "", photo: undefined });
    setErr("");
  };


  return (
    <div className="max-w-6xl">
      <PageHeader title="Staff" subtitle="Adaugă instructori și administratori. Dezactivează sau elimină accesul oricând." />

      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_360px]">
        <div className="border border-border bg-card">
          {staff.length === 0 ? (
            <div className="px-6 py-16 text-center">
              <UserCog strokeWidth={1} className="mx-auto h-8 w-8 text-muted-foreground" />
              <p className="mt-4 font-serif text-xl">Niciun membru încă</p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="border-b border-border text-left text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                <tr>
                  <th className="px-6 py-4 font-normal w-20">Foto</th>
                  <th className="px-6 py-4 font-normal">Nume</th>
                  <th className="px-6 py-4 font-normal">Rol</th>
                  <th className="px-6 py-4 font-normal">Contact</th>
                  <th className="px-6 py-4 font-normal">Status</th>
                  <th className="px-6 py-4 font-normal text-right">Acțiuni</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {staff.map((m) => (
                  <tr key={m.id} className={!m.active ? "opacity-50" : ""}>
                    <td className="px-6 py-4">
                      {m.photo ? (
                        <img src={m.photo} alt={m.name} className="h-12 w-12 rounded-full object-cover border border-border" />
                      ) : (
                        <div className="h-12 w-12 rounded-full border border-dashed border-border bg-secondary/40" />
                      )}
                    </td>
                    <td className="px-6 py-4 font-medium">{m.name}</td>
                    <td className="px-6 py-4 text-muted-foreground">{m.role}</td>

                    <td className="px-6 py-4 text-muted-foreground">
                      <div>{m.email}</div>
                      {m.phone && <div className="text-xs">{m.phone}</div>}
                    </td>
                    <td className="px-6 py-4 text-[10px] uppercase tracking-[0.2em]">
                      <span className={m.active ? "text-primary" : "text-muted-foreground"}>
                        {m.active ? "Activ" : "Inactiv"}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={() => setStaff(staff.map((x) => (x.id === m.id ? { ...x, active: !x.active } : x)))}
                        className="mr-3 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
                      >
                        {m.active ? "Dezactivează" : "Activează"}
                      </button>
                      <button
                        onClick={() => setConfirmDelete(m.id)}
                        className="inline-flex items-center gap-1 text-xs text-destructive/80 hover:text-destructive"
                      >
                        <Trash2 className="h-3 w-3" /> Șterge
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <form onSubmit={add} className="h-fit border border-border bg-card p-6 space-y-4">
          <h3 className="font-serif text-xl">Adaugă membru</h3>
          <Field label="Portret">
            <ImageUpload
              value={form.photo}
              onChange={(v) => setForm({ ...form, photo: v })}
              aspect="aspect-square"
              label="Adaugă portret profesional"
            />
          </Field>
          <Field label="Nume complet">
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full border border-border bg-background px-4 py-3 text-sm" />
          </Field>

          <Field label="Rol / Specializare">
            <input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} placeholder="ex. Reformer & Postură" className="w-full border border-border bg-background px-4 py-3 text-sm" />
          </Field>
          <Field label="Email">
            <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full border border-border bg-background px-4 py-3 text-sm" />
          </Field>
          <Field label="Telefon (opțional)">
            <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full border border-border bg-background px-4 py-3 text-sm" />
          </Field>
          {err && <p className="text-xs text-destructive">{err}</p>}
          <button className="w-full border border-foreground bg-foreground px-6 py-3 text-[11px] uppercase tracking-[0.28em] text-background hover:bg-transparent hover:text-foreground transition-all">
            <Plus className="inline h-3 w-3 mr-1" /> Adaugă în echipă
          </button>
        </form>
      </div>

      {confirmDelete && (
        <ConfirmDialog
          title="Elimină membrul"
          message="Persoana va fi ștearsă permanent din echipă."
          onCancel={() => setConfirmDelete(null)}
          onConfirm={() => { setStaff(staff.filter((x) => x.id !== confirmDelete)); setConfirmDelete(null); }}
        />
      )}
    </div>
  );
}

/* ---------- Location ---------- */
function LocationSettings() {
  const [data, setData] = useState({
    name: "Meymoon Studio",
    address: "Strada Rodiei 57, București 030955, România",
    capacity: 24,
    changing: true,
    naturalLight: true,
    tea: true,
    teaDetail: "Infuzii organice · matcha bar",
  });
  const [saved, setSaved] = useState(false);

  return (
    <div className="max-w-3xl">
      <PageHeader title="Locație & Facilități" subtitle="Detalii sincronizate cu pagina publică a studioului." />
      <form
        className="mt-10 space-y-5 border border-border bg-card p-8"
        onSubmit={(e) => { e.preventDefault(); setSaved(true); setTimeout(() => setSaved(false), 2000); }}
      >
        <Field label="Nume studio">
          <input value={data.name} onChange={(e) => setData({ ...data, name: e.target.value })} className="w-full border border-border bg-background px-4 py-3 text-sm" />
        </Field>
        <Field label="Adresă">
          <input value={data.address} onChange={(e) => setData({ ...data, address: e.target.value })} className="w-full border border-border bg-background px-4 py-3 text-sm" />
        </Field>
        <Field label="Capacitate maximă">
          <input type="number" value={data.capacity} onChange={(e) => setData({ ...data, capacity: +e.target.value })} className="w-full border border-border bg-background px-4 py-3 text-sm" />
        </Field>
        <div className="space-y-3 pt-4">
          <Toggle label="Vestiare" checked={data.changing} onChange={(v) => setData({ ...data, changing: v })} />
          <Toggle label="Lumină naturală" checked={data.naturalLight} onChange={(v) => setData({ ...data, naturalLight: v })} />
          <Toggle label="Ceainărie" checked={data.tea} onChange={(v) => setData({ ...data, tea: v })} />
        </div>
        <Field label="Detalii ceainărie">
          <input value={data.teaDetail} onChange={(e) => setData({ ...data, teaDetail: e.target.value })} className="w-full border border-border bg-background px-4 py-3 text-sm" />
        </Field>
        <button className="border border-foreground bg-foreground px-8 py-3 text-[11px] uppercase tracking-[0.28em] text-background hover:bg-transparent hover:text-foreground transition-all">
          Salvează
        </button>
        {saved && <p className="text-xs text-primary">✓ Setări salvate.</p>}
      </form>
    </div>
  );
}

/* ---------- Newsletter ---------- */
function NewsletterBroadcast({
  subscribers,
  newsletters,
  setNewsletters,
}: {
  subscribers: number;
  newsletters: Newsletter[];
  setNewsletters: (v: Newsletter[]) => void;
}) {
  const [subject, setSubject] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "sent">("idle");
  const [err, setErr] = useState("");
  const editorRef = useRef<HTMLDivElement>(null);
  const [bodyText, setBodyText] = useState("");

  const exec = (cmd: string, value?: string) => {
    editorRef.current?.focus();
    document.execCommand(cmd, false, value);
    setBodyText(editorRef.current?.innerText.trim() ?? "");
  };

  const onSend = (e: React.FormEvent) => {
    e.preventDefault();
    const html = editorRef.current?.innerHTML ?? "";
    const plain = editorRef.current?.innerText.trim() ?? "";

    if (!subject.trim()) return setErr("Subiectul este obligatoriu");
    if (subject.trim().length < 4) return setErr("Subiectul trebuie să aibă minim 4 caractere");
    if (subject.length > 120) return setErr("Subiectul depășește 120 caractere");
    if (!plain) return setErr("Conținutul nu poate fi gol");
    if (plain.length < 10) return setErr("Conținutul trebuie să aibă minim 10 caractere");

    setErr("");
    setState("sending");
    setTimeout(() => {
      const preview = plain.slice(0, 90) + (plain.length > 90 ? "…" : "");
      setNewsletters([
        {
          id: `n${Date.now()}`,
          subject,
          sentAt: new Date().toISOString().slice(0, 16).replace("T", " "),
          status: "Sent",
          recipients: subscribers,
          preview,
        },
        ...newsletters,
      ]);
      setState("sent");
      setSubject("");
      if (editorRef.current) editorRef.current.innerHTML = "";
      setBodyText("");
      // ignore HTML for now — log table shows preview
      void html;
      setTimeout(() => setState("idle"), 3000);
    }, 1800);
  };

  const charCount = bodyText.length;

  return (
    <div className="max-w-5xl">
      <PageHeader title="Newsletter Broadcast" subtitle={`${subscribers.toLocaleString()} abonați primesc ritualurile tale.`} />

      <form className="mt-10 border border-border bg-card p-8" onSubmit={onSend}>
        <Field label="Subiect email">
          <input
            value={subject}
            onChange={(e) => { setSubject(e.target.value); setErr(""); }}
            placeholder="Un ritual liniștit pentru săptămâna nouă"
            maxLength={140}
            className="w-full border border-border bg-background px-4 py-3 text-sm"
          />
          <span className="mt-1 block text-right text-[10px] text-muted-foreground">{subject.length}/120</span>
        </Field>

        <div className="mt-5">
          <span className="mb-2 block text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Conținut</span>
          <div className="flex flex-wrap items-center gap-1 border border-b-0 border-border bg-secondary/30 px-2 py-2">
            <ToolbarBtn onClick={() => exec("bold")} title="Bold"><Bold className="h-3.5 w-3.5" /></ToolbarBtn>
            <ToolbarBtn onClick={() => exec("italic")} title="Italic"><Italic className="h-3.5 w-3.5" /></ToolbarBtn>
            <ToolbarBtn onClick={() => exec("underline")} title="Subliniat"><Underline className="h-3.5 w-3.5" /></ToolbarBtn>
            <ToolbarBtn onClick={() => exec("insertUnorderedList")} title="Listă"><List className="h-3.5 w-3.5" /></ToolbarBtn>
            <ToolbarBtn
              onClick={() => {
                const url = window.prompt("Adresa URL (https://...)");
                if (url) exec("createLink", url);
              }}
              title="Link"
            >
              <Link2 className="h-3.5 w-3.5" />
            </ToolbarBtn>
            <div className="mx-2 h-4 w-px bg-border" />
            <select
              onChange={(e) => { exec("formatBlock", e.target.value); e.target.value = ""; }}
              className="bg-transparent text-xs text-muted-foreground outline-none"
              defaultValue=""
            >
              <option value="" disabled>Stil</option>
              <option value="H2">Titlu</option>
              <option value="H3">Subtitlu</option>
              <option value="P">Paragraf</option>
              <option value="BLOCKQUOTE">Citat</option>
            </select>
          </div>
          <div
            ref={editorRef}
            contentEditable
            suppressContentEditableWarning
            onInput={() => { setBodyText(editorRef.current?.innerText.trim() ?? ""); setErr(""); }}
            className="min-h-[220px] w-full border border-border bg-background px-4 py-3 text-sm leading-relaxed outline-none focus:border-foreground prose-newsletter"
          />
          <span className="mt-1 block text-right text-[10px] text-muted-foreground">{charCount} caractere</span>
        </div>

        {err && <p className="mt-3 text-xs text-destructive">{err}</p>}

        <div className="mt-6 flex items-center justify-between">
          <span className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
            {state === "sending" && "Se trimite broadcast..."}
            {state === "sent" && `✓ Trimis cu succes către ${subscribers.toLocaleString()} abonați`}
          </span>
          <button
            disabled={state === "sending"}
            className="inline-flex items-center gap-2 border border-foreground bg-foreground px-8 py-3 text-[11px] uppercase tracking-[0.28em] text-background hover:bg-transparent hover:text-foreground transition-all disabled:opacity-50"
          >
            <Send className="h-3.5 w-3.5" />
            {state === "sending" ? "Trimit..." : "Trimite broadcast"}
          </button>
        </div>
      </form>

      <div className="mt-12 border border-border bg-card">
        <div className="flex items-center justify-between border-b border-border px-6 py-4">
          <h3 className="font-serif text-lg">Istoric broadcast-uri</h3>
          <span className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{newsletters.length} expediate</span>
        </div>
        {newsletters.length === 0 ? (
          <p className="px-6 py-10 text-sm text-muted-foreground">Niciun newsletter trimis încă.</p>
        ) : (
          <table className="w-full text-sm">
            <thead className="text-left text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              <tr>
                <th className="px-6 py-3 font-normal">Subiect</th>
                <th className="px-6 py-3 font-normal">Dată</th>
                <th className="px-6 py-3 font-normal">Destinatari</th>
                <th className="px-6 py-3 font-normal">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {newsletters.map((n) => (
                <tr key={n.id}>
                  <td className="px-6 py-4">
                    <div className="font-medium">{n.subject}</div>
                    <div className="text-xs text-muted-foreground">{n.preview}</div>
                  </td>
                  <td className="px-6 py-4 text-muted-foreground">{n.sentAt}</td>
                  <td className="px-6 py-4">{n.recipients.toLocaleString()}</td>
                  <td className="px-6 py-4 text-[10px] uppercase tracking-[0.2em]">
                    <span className={n.status === "Sent" ? "text-primary" : "text-destructive"}>{n.status === "Sent" ? "Expediat" : "Eșuat"}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

/* ---------- Helpers ---------- */
function PageHeader({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-[0.35em] text-muted-foreground">Staff Portal</p>
      <h1 className="mt-3 font-serif text-4xl">{title}</h1>
      <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-2 block text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center justify-between border border-border bg-background px-4 py-3">
      <span className="text-sm">{label}</span>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className={`relative h-5 w-10 transition-colors ${checked ? "bg-foreground" : "bg-border"}`}
      >
        <span className={`absolute top-0.5 h-4 w-4 bg-background transition-all ${checked ? "left-[22px]" : "left-0.5"}`} />
      </button>
    </label>
  );
}

function ToolbarBtn({ onClick, title, children }: { onClick: () => void; title: string; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onMouseDown={(e) => { e.preventDefault(); onClick(); }}
      title={title}
      className="flex h-7 w-7 items-center justify-center text-foreground/70 hover:bg-background hover:text-foreground transition-colors"
    >
      {children}
    </button>
  );
}

function ConfirmDialog({ title, message, onCancel, onConfirm }: { title: string; message: string; onCancel: () => void; onConfirm: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4">
      <div className="w-full max-w-md border border-border bg-background p-8 shadow-2xl">
        <h3 className="font-serif text-2xl">{title}</h3>
        <p className="mt-3 text-sm text-muted-foreground">{message}</p>
        <div className="mt-8 flex justify-end gap-3">
          <button
            onClick={onCancel}
            className="px-5 py-2.5 text-[10px] uppercase tracking-[0.25em] text-muted-foreground hover:text-foreground"
          >
            Anulează
          </button>
          <button
            onClick={onConfirm}
            className="border border-destructive bg-destructive px-6 py-2.5 text-[10px] uppercase tracking-[0.25em] text-destructive-foreground hover:bg-transparent hover:text-destructive transition-all"
          >
            Șterge definitiv
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------- Events Manager ---------- */
function EventsManager({ events, setEvents }: { events: EventItem[]; setEvents: (v: EventItem[]) => void }) {
  const [form, setForm] = useState<Omit<EventItem, "id">>({ title: "", description: "", date: "", time: "", image: undefined });
  const [err, setErr] = useState("");
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const add = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) return setErr("Titlul este obligatoriu");
    if (!form.date) return setErr("Data este obligatorie");
    setEvents([...events, { ...form, id: `e${Date.now()}` }]);
    setForm({ title: "", description: "", date: "", time: "", image: undefined });
    setErr("");
  };

  return (
    <div className="max-w-6xl">
      <PageHeader title="Evenimente & Workshops" subtitle="Publică workshopuri și evenimente speciale cu banner promoțional." />

      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_400px]">
        <div className="border border-border bg-card">
          {events.length === 0 ? (
            <div className="px-6 py-16 text-center">
              <Sparkles strokeWidth={1} className="mx-auto h-8 w-8 text-muted-foreground" />
              <p className="mt-4 font-serif text-xl">Niciun eveniment programat</p>
              <p className="mt-2 text-sm text-muted-foreground">Adaugă un workshop pentru a-l publica pe site.</p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="border-b border-border text-left text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                <tr>
                  <th className="px-6 py-4 font-normal w-28">Banner</th>
                  <th className="px-6 py-4 font-normal">Titlu</th>
                  <th className="px-6 py-4 font-normal">Data</th>
                  <th className="px-6 py-4 font-normal text-right">Acțiuni</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {events.map((ev) => (
                  <tr key={ev.id}>
                    <td className="px-6 py-4">
                      {ev.image ? (
                        <img src={ev.image} alt={ev.title} className="h-16 w-24 object-cover border border-border" />
                      ) : (
                        <div className="h-16 w-24 border border-dashed border-border bg-secondary/40" />
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium">{ev.title}</div>
                      <div className="text-xs text-muted-foreground">{ev.description}</div>
                    </td>
                    <td className="px-6 py-4 text-muted-foreground">
                      {ev.date}{ev.time && ` · ${ev.time}`}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={() => setConfirmDelete(ev.id)}
                        className="inline-flex items-center gap-1 text-xs text-destructive/80 hover:text-destructive"
                      >
                        <Trash2 className="h-3 w-3" /> Șterge
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <form onSubmit={add} className="h-fit border border-border bg-card p-6 space-y-4">
          <h3 className="font-serif text-xl">Eveniment nou</h3>
          <Field label="Banner promoțional">
            <ImageUpload
              value={form.image}
              onChange={(v) => setForm({ ...form, image: v })}
              aspect="aspect-[16/9]"
              label="Trage banner eveniment aici · sau apasă pentru upload"
            />
          </Field>
          <Field label="Titlu">
            <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full border border-border bg-background px-4 py-3 text-sm" />
          </Field>
          <Field label="Descriere">
            <textarea rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="w-full border border-border bg-background px-4 py-3 text-sm" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Data">
              <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="w-full border border-border bg-background px-4 py-3 text-sm" />
            </Field>
            <Field label="Ora">
              <input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} className="w-full border border-border bg-background px-4 py-3 text-sm" />
            </Field>
          </div>
          {err && <p className="text-xs text-destructive">{err}</p>}
          <button className="w-full border border-foreground bg-foreground px-6 py-3 text-[11px] uppercase tracking-[0.28em] text-background hover:bg-transparent hover:text-foreground transition-all">
            <Plus className="inline h-3 w-3 mr-1" /> Publică eveniment
          </button>
        </form>
      </div>

      {confirmDelete && (
        <ConfirmDialog
          title="Șterge evenimentul"
          message="Evenimentul va fi eliminat permanent."
          onCancel={() => setConfirmDelete(null)}
          onConfirm={() => { setEvents(events.filter((x) => x.id !== confirmDelete)); setConfirmDelete(null); }}
        />
      )}
    </div>
  );
}

/* ---------- Reservations ---------- */
function ReservationsManager({ reservations, setReservations }: { reservations: Reservation[]; setReservations: (v: Reservation[]) => void }) {
  const [filter, setFilter] = useState<"all" | Reservation["status"]>("all");
  const [query, setQuery] = useState("");

  const filtered = reservations
    .filter((r) => (filter === "all" ? true : r.status === filter))
    .filter((r) => {
      const q = query.trim().toLowerCase();
      if (!q) return true;
      return (
        r.clientName.toLowerCase().includes(q) ||
        r.className.toLowerCase().includes(q) ||
        r.instructor.toLowerCase().includes(q)
      );
    })
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));

  const total = reservations.length;
  const confirmed = reservations.filter((r) => r.status === "Confirmată").length;
  const pending = reservations.filter((r) => r.status === "În așteptare").length;

  const statusClass = (s: Reservation["status"]) =>
    s === "Confirmată"
      ? "bg-primary/15 text-primary"
      : s === "În așteptare"
        ? "bg-amber-500/15 text-amber-700"
        : "bg-destructive/15 text-destructive";

  return (
    <div className="max-w-6xl">
      <PageHeader title="Rezervări" subtitle="Toate persoanele care au rezervat o clasă." />

      <div className="mt-10 grid gap-5 sm:grid-cols-3">
        <div className="border border-border bg-card p-6">
          <div className="font-serif text-4xl">{total}</div>
          <div className="mt-2 text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Total rezervări</div>
        </div>
        <div className="border border-border bg-card p-6">
          <div className="font-serif text-4xl">{confirmed}</div>
          <div className="mt-2 text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Confirmate</div>
        </div>
        <div className="border border-border bg-card p-6">
          <div className="font-serif text-4xl">{pending}</div>
          <div className="mt-2 text-[10px] uppercase tracking-[0.25em] text-muted-foreground">În așteptare</div>
        </div>
      </div>

      <div className="mt-8 flex flex-wrap items-center gap-3">
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Caută client, clasă sau instructor…"
          className="flex-1 min-w-[240px] border border-border bg-background px-4 py-3 text-sm outline-none focus:border-foreground"
        />
        <div className="flex gap-1">
          {(["all", "Confirmată", "În așteptare", "Anulată"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-3 text-[10px] uppercase tracking-[0.2em] transition-colors ${
                filter === f ? "bg-foreground text-background" : "border border-border text-foreground/70 hover:bg-secondary"
              }`}
            >
              {f === "all" ? "Toate" : f}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6 border border-border bg-card">
        {filtered.length === 0 ? (
          <div className="px-6 py-16 text-center">
            <ClipboardList strokeWidth={1} className="mx-auto h-8 w-8 text-muted-foreground" />
            <p className="mt-4 font-serif text-xl">Nicio rezervare</p>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead className="border-b border-border text-left text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              <tr>
                <th className="px-6 py-4 font-normal">Client</th>
                <th className="px-6 py-4 font-normal">Clasă</th>
                <th className="px-6 py-4 font-normal">Instructor</th>
                <th className="px-6 py-4 font-normal">Dată & Oră</th>
                <th className="px-6 py-4 font-normal">Status</th>
                <th className="px-6 py-4 font-normal text-right">Acțiuni</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((r) => (
                <tr key={r.id}>
                  <td className="px-6 py-4">
                    <div className="font-medium">{r.clientName}</div>
                    <div className="text-xs text-muted-foreground">{r.clientEmail}</div>
                  </td>
                  <td className="px-6 py-4">{r.className}</td>
                  <td className="px-6 py-4 text-muted-foreground">{r.instructor}</td>
                  <td className="px-6 py-4">
                    <div>{r.date}</div>
                    <div className="text-xs text-muted-foreground">{r.time}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 text-[10px] uppercase tracking-[0.2em] ${statusClass(r.status)}`}>
                      {r.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    {r.status !== "Confirmată" && (
                      <button
                        onClick={() => setReservations(reservations.map((x) => (x.id === r.id ? { ...x, status: "Confirmată" } : x)))}
                        className="mr-3 inline-flex items-center gap-1 text-xs text-primary hover:opacity-80"
                      >
                        <CheckCircle2 className="h-3 w-3" /> Confirmă
                      </button>
                    )}
                    <button
                      onClick={() => setReservations(reservations.filter((x) => x.id !== r.id))}
                      className="inline-flex items-center gap-1 text-xs text-destructive/80 hover:text-destructive"
                    >
                      <Trash2 className="h-3 w-3" /> Șterge
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

