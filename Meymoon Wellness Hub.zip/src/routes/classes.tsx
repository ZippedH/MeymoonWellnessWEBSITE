import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/classes")({
  head: () => ({
    meta: [
      { title: "Classes — Meymoon" },
      { name: "description", content: "Pilates Reformer, Mat, Yoga, Breathwork, Sound Healing and more — discover the Meymoon class catalogue." },
    ],
  }),
  component: ClassesPage,
});

function ClassesPage() {
  return (
    <div className="px-6 pb-32 pt-40 lg:px-10">
      <div className="mx-auto max-w-3xl text-center">
        <p className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">Practices</p>
        <h1 className="mt-4 font-serif text-5xl md:text-6xl">Classes</h1>
        <p className="mt-6 text-base text-muted-foreground">
          A curated collection of movement and restorative practices. Detailed pages coming soon.
        </p>
        <Link to="/" className="mt-12 inline-block text-[11px] uppercase tracking-[0.28em] hover:underline underline-offset-8">
          ← Back home
        </Link>
      </div>
    </div>
  );
}
