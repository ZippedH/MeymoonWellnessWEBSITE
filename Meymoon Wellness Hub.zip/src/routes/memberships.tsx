import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/memberships")({
  head: () => ({
    meta: [
      { title: "Memberships — Meymoon" },
      { name: "description", content: "Unlimited, packages and private Reformer memberships." },
    ],
  }),
  component: MembershipsPage,
});

function MembershipsPage() {
  return (
    <div className="px-6 pb-32 pt-40 lg:px-10">
      <div className="mx-auto max-w-3xl text-center">
        <p className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">Pricing</p>
        <h1 className="mt-4 font-serif text-5xl md:text-6xl">Memberships</h1>
        <p className="mt-6 text-base text-muted-foreground">
          Elegant pricing cards coming next.
        </p>
        <Link to="/" className="mt-12 inline-block text-[11px] uppercase tracking-[0.28em] hover:underline underline-offset-8">
          ← Back home
        </Link>
      </div>
    </div>
  );
}
