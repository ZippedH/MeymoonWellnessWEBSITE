import { MapPin, ArrowUpRight } from "lucide-react";

const MAPS_QUERY = encodeURIComponent("Strada Rodiei 57, Bucharest 030955, Romania");
const ADDRESS = "Strada Rodiei 57, București 030955";

export function StudioMap({
  eyebrow = "Locație",
  title = "Ne găsești aici",
  height = "h-[420px] md:h-[520px]",
  showCta = true,
}: {
  eyebrow?: string;
  title?: string;
  height?: string;
  showCta?: boolean;
}) {
  return (
    <div className="w-full">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">{eyebrow}</p>
          <h2 className="mt-3 font-serif text-3xl md:text-4xl">{title}</h2>
          <p className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-3.5 w-3.5" strokeWidth={1.4} /> {ADDRESS}
          </p>
        </div>
        {showCta && (
          <a
            href={`https://www.google.com/maps/search/?api=1&query=${MAPS_QUERY}`}
            target="_blank"
            rel="noreferrer noopener"
            className="inline-flex w-fit items-center gap-2 text-[10px] uppercase tracking-[0.28em] text-foreground hover:gap-3 transition-all"
          >
            Deschide în Google Maps <ArrowUpRight className="h-3.5 w-3.5" />
          </a>
        )}
      </div>

      <div className={`relative mt-8 overflow-hidden border border-border bg-secondary/40 ${height}`}>
        <iframe
          title="Meymoon Studio — Strada Rodiei 57, București"
          src={`https://www.google.com/maps?q=${MAPS_QUERY}&z=16&hl=ro&output=embed`}
          className="block h-full w-full"
          style={{ border: 0, filter: "grayscale(20%) contrast(0.96) sepia(6%)" }}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          allowFullScreen
        />
        <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-foreground/5" />
      </div>
    </div>
  );
}
