import { X } from "lucide-react";
import type { ReactNode } from "react";

export function LegalModal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/50 p-4 animate-in fade-in">
      <div
        className="relative w-full max-w-xl max-h-[85vh] overflow-y-auto border border-border bg-background shadow-2xl animate-in slide-in-from-bottom-4"
        role="dialog"
        aria-modal="true"
      >
        <button
          aria-label="Închide"
          onClick={onClose}
          className="absolute right-5 top-5 text-muted-foreground hover:text-foreground transition-colors"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="px-8 py-10 md:px-12 md:py-14">
          <p className="text-[10px] uppercase tracking-[0.35em] text-muted-foreground">Meymoon</p>
          <h2 className="mt-3 font-serif text-3xl md:text-4xl">{title}</h2>
          <div className="mt-8 space-y-4 text-sm leading-relaxed text-foreground/85 whitespace-pre-line">
            {children}
          </div>
          <button
            onClick={onClose}
            className="mt-10 border border-foreground bg-foreground px-8 py-3 text-[10px] uppercase tracking-[0.28em] text-background hover:bg-transparent hover:text-foreground transition-all"
          >
            Am înțeles
          </button>
        </div>
      </div>
    </div>
  );
}
