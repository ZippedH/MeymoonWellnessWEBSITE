import { useRef, useState } from "react";
import { UploadCloud, X } from "lucide-react";

export function ImageUpload({
  value,
  onChange,
  label = "Trage imaginea aici · sau apasă pentru upload",
  aspect = "aspect-[4/3]",
}: {
  value?: string;
  onChange: (dataUrl: string | undefined) => void;
  label?: string;
  aspect?: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  const handleFile = (file?: File | null) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = () => onChange(String(reader.result));
    reader.readAsDataURL(file);
  };

  if (value) {
    return (
      <div className={`relative overflow-hidden border border-border bg-secondary/40 ${aspect}`}>
        <img src={value} alt="Preview" className="h-full w-full object-cover" />
        <button
          type="button"
          onClick={() => onChange(undefined)}
          className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center bg-background/90 text-foreground hover:bg-background transition-colors"
          aria-label="Elimină imaginea"
        >
          <X className="h-3.5 w-3.5" />
        </button>
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="absolute bottom-2 right-2 bg-background/90 px-3 py-1.5 text-[10px] uppercase tracking-[0.2em] hover:bg-background"
        >
          Schimbă
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0])}
        />
      </div>
    );
  }

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        handleFile(e.dataTransfer.files?.[0]);
      }}
      onClick={() => inputRef.current?.click()}
      className={`flex ${aspect} cursor-pointer flex-col items-center justify-center border border-dashed transition-colors ${
        dragging ? "border-foreground bg-secondary" : "border-border bg-secondary/40 hover:border-foreground/60"
      }`}
    >
      <UploadCloud className="h-6 w-6 text-muted-foreground" strokeWidth={1.2} />
      <p className="mt-3 px-4 text-center text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground/70">JPG · PNG · max 5MB</p>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])}
      />
    </div>
  );
}
